import{a as t}from"../chunks/entry.BB8nojDZ.js";export{t as start};
