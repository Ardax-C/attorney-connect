import{a as t}from"../chunks/entry.DXEphUPW.js";export{t as start};
