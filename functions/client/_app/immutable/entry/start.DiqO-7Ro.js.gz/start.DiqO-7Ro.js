import{a as t}from"../chunks/entry.Bg3xBhrT.js";export{t as start};
