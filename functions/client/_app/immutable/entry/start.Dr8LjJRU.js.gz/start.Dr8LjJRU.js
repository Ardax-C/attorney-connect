import{a as t}from"../chunks/entry.CopdTw2I.js";export{t as start};
